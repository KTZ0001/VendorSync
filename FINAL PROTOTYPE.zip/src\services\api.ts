import axios from 'axios';

const api = axios.create({
  // Force use of 127.0.0.1 to avoid IPv6/localhost resolution delays and CORS issues
  baseURL: 'http://127.0.0.1:3001',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10s timeout
});

// Add interceptor to handle auth tokens if they exist
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
